#ifndef MODE_SELECTOR_H
#define MODE_SELECTOR_H

void runCurrentMode();

#endif