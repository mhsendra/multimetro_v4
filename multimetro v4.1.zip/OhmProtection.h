#ifndef OHM_PROTECTION_H
#define OHM_PROTECTION_H

bool detectVoltageOnOhm();

#endif