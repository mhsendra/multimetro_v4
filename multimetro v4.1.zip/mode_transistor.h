#ifndef MODE_TRANSISTOR_H
#define MODE_TRANSISTOR_H

#include <Arduino.h>

void showTransistor();

#endif

