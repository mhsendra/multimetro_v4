#ifndef MODE_DIODE_H
#define MODE_DIODE_H

float measureDiode_raw();
float measureDiode_main();
void showDiode();
void measureDiodeMode();

#endif