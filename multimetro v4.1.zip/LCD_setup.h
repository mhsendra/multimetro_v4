#ifndef LCD_SETUP_H
#define LCD_SETUP_H

#include <Arduino.h>
#include <LiquidCrystal_I2C.h>

// Inicialización del LCD
void lcd_setup();

#endif
